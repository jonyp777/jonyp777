from http.server import HTTPServer, SimpleHTTPRequestHandler, ThreadingHTTPServer

from io import BytesIO
from urllib.parse import urlparse
from urllib.parse import unquote
from urllib.parse import quote
# import pyodbc
import json
from datetime import datetime
import time
import os
import aniso8601
import json
import requests
import uuid
import urllib.request
import urllib.parse
import pymysql

from datetime import datetime
#import standard_utils

# database ="movedb"
print("program started\n")
# print("read config file: db= ", {database})
# print(database)
# print(f'Driver={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={database};')
omone = ""
oreading_date = ""

config = json.load(open(os.path.join(os.path.dirname(__file__), "config_my.json")))

print(config)

database = config["database"]
SERVER_IP = config["SERVER_IP"]
user = config["user"]
password = config["password"]


def my_open(datab):
    print ("datab=",datab, "localhost")
    if datab == "":
        db = pymysql.connect(
            host="localhost",
            user=user,
            passwd=password,
        )
        print("connected to mysql")
        mycursor = db.cursor()
        return (mycursor, db)

    else:
        db = pymysql.connect(
            host="localhost",
            user=user,
            passwd=password,
            database=datab,
            autocommit=1,
        )
        print("db opened", db)
        mycursor = db.cursor()
        return (mycursor, db)





def aalt_open(datab):
    if datab == "":
        db =  pymysql.connect(
            host="31.220.61.40",
            user="jony",
            passwd=8341455,
        )
        print("connected to mysql")
        mycursor = db.cursor()
        return (mycursor, db)

    else:
        db =  pymysql.connect(
            host="31.220.61.40",
            user="jony",
            passwd="8341455",
            database= datab ,
            autocommit=1,

        )
        print("db opened", db)
        mycursor = db.cursor()
        return (mycursor, db)


# mycursor, my_db = my_open(database)


############my_altcursor,my_db =alt_open("move_ver3")

mycursor, my_db = my_open(database)
#mycursor, my_db = aalt_open(database)



from datetime import date

now = datetime.now()
s1 = now.strftime("%d/%m/%Y")
s2 = now.strftime("%d/%m/%Y %H:%M")
print("s2 =", s2)

# standard_utils.get_all_values(mycursor)

def add_log(my_cursor,day_date,description,qty,status):
    sql= "insert into log (day_date,description,qty,status) values (%s,%s,%s,%s)"
    val= (day_date,description,qty,status)
    my_cursor.execute (sql,val)

def alarms(my_cursor, day_date, mone, alarm_no, qty, details, priority, status):
    print(" a l a r m s",mone,alarm_no)
    now = datetime.now()

    dt_string = now.strftime("%Y/%m/%d %H:%M:%S")
    sql = "select day_date from alarms where day_date= %s and mone= %s and alarm_index= %s"
    val = (day_date, mone, alarm_no)
    my_cursor.execute(sql, val)
    result = my_cursor.fetchall()
    y_list = list(result)
    if y_list:
        print("alarm exists",alarm_no)
    else:
        print("*** new  alarm ***")
        sql = "INSERT into alarms  ( day_date,mone,alarm_index,alarm_description,qty,inserted_at,priority,status) values   (%s,%s,%s,%s,%s,%s ,%s,%s)"
        val = (day_date, mone, alarm_no, details, qty, dt_string, priority, status)
        print(sql)
        print(val)
        my_cursor.execute(sql, val)
        # conn.commit()
        return ("OK")

def new_find_in_yomi(my_cursor, day_date, mone):
    # check if this record exists
    sql = "select mone from kriot_yomi where day_date= %s and mone = %s  "
    val = (day_date, mone)
    my_cursor.execute(sql, val)
    res = my_cursor.fetchall()
    tmp = list(res)
    print(tmp)
    if tmp:
        f = 0  # exists
        print("=== exists ***")
    else:
        f = 1
        print("does not exist")
    return (f)

def new_ratsif2yomi(my_cursor, from_date):
    print("new ratsif_yomi")
    count_mone = 0
    count_dates = 0
    count_updated=0
    count_inserted=0
    sql = "SELECT  MAX(water_count) ,mone,reading_day from kriot_ratsif where reading_day>=%s GROUP BY mone,reading_day order by mone asc ,reading_day asc "
    val = (from_date)
    my_cursor.execute(sql, val)
    result = my_cursor.fetchall()
    old_mone = ""
    old_last_reading = 0
    count_mone = count_mone + 1
    for i in list(result):
        print(i)
        qtmp=i[0]
        count_dates = count_dates + 1
        if i[1] != old_mone:
            old_last_reading = qtmp
        else:
            if old_last_reading > qtmp:
                #alarms(my_cursor, day_date, mone, alarm_no, qty, details, priority, status):
                description = "lower "+str (old_last_reading) +" - " +str(i[0])
                delta= qtmp-old_last_reading

                #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                #@@@@   patch for low qty     ******************
                qtmp=old_last_reading

                alarms(my_cursor, i[2],i[1], 104, delta, description, 0, 0)
                print ("alarm-low ",i[2],i[1],i[0] )
                #old_last_reading = i[0]  # i asume - hchlafat_mone

        old_mone = i[1]
        mone = i[1]
        last_reading = qtmp
        day_date = i[2]

        # check if this record exists
        f = new_find_in_yomi(my_cursor, day_date, mone)
        if f == 0:
            sql = "update kriot_yomi set  day_date=%s ,mone=%s ,former_reading=%s ,last_reading=%s  where day_date=%s and mone=%s"
            val = (day_date, mone, old_last_reading, last_reading, day_date, mone)
            count_updated=count_updated+1

        else:
            sql = "insert into kriot_yomi (day_date, mone ,former_reading ,last_reading  ) values (%s,%s,%s,%s)"
            val = (day_date, mone, old_last_reading, last_reading)
            count_inserted=count_inserted+1

        my_cursor.execute(sql, val)
        old_last_reading = i[0]
    add_log(my_cursor, day_date, "ratsif_to_yomi inserted", count_inserted, "0")
    add_log(my_cursor, day_date, "ratsif_to_yomi updated", count_updated, "0")


def update_last_transmission(my_cursor):
    print ("@@@@@@@@@@@ last_transmit @@@@@@@@@@@@@@@@@@@")
    sql="select mone,neches from monim"
    my_cursor.execute (sql)
    result= my_cursor.fetchall()
    y_list=list (result)
    count_ok=0
    count_nok=0


    for y in y_list:
        mone=y[0]
        neches=y[1]
        sql = "select day_date,last_reading from kriot_yomi where mone=%s order by day_date  desc limit 1"
        val=( mone)
        my_cursor.execute(sql,val)
        result1 = my_cursor.fetchall()

        z_list = list(result1)
        if z_list:
            for z in z_list:
                day_date=z[0]
                last_reading = z[1]

                count_ok=count_ok+1
                sql= "update monim set last_transmission = %s , last_reading_value=%s where mone=%s"
                val = (day_date,last_reading ,mone)
                my_cursor.execute(sql, val)
                print (val)



        else:
            print (mone,"not_found")
            count_nok=count_nok+1
        sql = "update kriot_yomi set neches = %s where mone=%s and neches is NULL"
        val = (neches, mone)

        my_cursor.execute(sql, val)
        print ("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^",val)

    add_log(my_cursor, day_date, "total last transmission monim updated",count_ok,"0")
    add_log(my_cursor, day_date, "total last transmission monim not updated", count_nok, "1")

def calculate_virtual_monim(my_cursor):
    print ("entered calculate virtual")
    # found all virtuals
    sql ="select virtual_mone,real_mone from virtual_monim order by calculation_order"
    my_cursor.execute(sql)
    result=my_cursor.fetchall()
    y_list=list(result)
    if (y_list):
        for y in y_list:
             v_mone=y[0]
             real_mone=y[1]
             print (v_mone,real_mone)
             #found all dates in for each real mone
             sql =" select day_date,former_reading,last_reading,balance,real_qty from kriot_yomi where mone=%s"
             val = real_mone
             my_cursor.execute(sql,val)
             result1=mycursor.fetchall()
             z_list=list (result1)

             for  z in z_list:
                 print (z)
                 day_date= z[0]
                 former_reading =z[1]
                 last_reading=z[2]
                 balance =z[3]
                 real_qty=z[4]
                 # check if exists
                 sql = "select record_number from kriot_yomi where day_date=%s and mone=%s"
                 val=(day_date,v_mone)
                 #find if
                 my_cursor.execute (sql,val)
                 temp_result = my_cursor.fetchall()
                 temp =list (temp_result)
                 if temp :# update record
                     for r in temp:
                        sql = "update kriot_yomi set former_reading =%s,last_reading=%s,balance=%s,real_qty=%s where record_number=%s"
                        val=(former_reading,last_reading,balance,real_qty,r[0])
                        my_cursor.execute(sql, val)
                        print ("updating")
                 else:
                     sql = "insert into kriot_yomi (mone, day_date,former_reading,last_reading,balance,real_qty ) values ( %s,%s,%s,%s,%s,%s )"
                     val = (v_mone,day_date,former_reading, last_reading, balance, real_qty )
                     print ("inserting new")
                     my_cursor.execute(sql, val)


def calculate_qty_in_ratsif(my_cursor):
    print("&&&&&&&&&&&&&&&&&&&&&&&&&&")
    print("$                        $")
    print("calculating qty in ratsif ")
    print("$      it takes time      $")
    print("$                         $")
    print("&&&&&&&&&&&&&&&&&&&&&& &&&&")

    count_update = 0
    sql = "select record_number,mone,water_count from kriot_ratsif where qty is null  order by mone asc,reading_date limit 10000000"
    my_cursor.execute(sql)
    result = my_cursor.fetchall()
    print(result)
    old_mone = 0
    old_reading = 0
    old_qty = 0
    for y in list(result):
        count_update = count_update + 1
        record_number = y[0]
        mone = y[1]
        water_count = y[2]
        if old_mone != mone:
            old_mone = y[1]
            old_water_count = y[2]
        if water_count == "None":
            water_count = 0
        qty = water_count - old_water_count
        old_water_count = water_count
        sql = "update kriot_ratsif set qty=%s where record_number =%s"
        val = (qty, record_number)
        print(mone, val)
        my_cursor.execute(sql, val)
    add_log(my_cursor, now, "calculating qty in ratsif ", count_update, "0")



# ################################################################################
# ################################################################################


# ################################################################################


# ################################################################################


def is_neches(my_cursor,neches):
    print ("entered  is_neches",neches)
    sql="select neches from customers where neches=%s"
    val = (neches)
    my_cursor.execute (sql,val)
    result=my_cursor.fetchall()
    print (result)
    if result:
        return (1)
    else:
        return (0)

def is_mone_neches(my_cursor,mone,neches):
    print ("is mone neches",mone,neches)
    sql = "select mone,neches from customers where mone=%s and neches=%s"
    val = (mone,neches)
    my_cursor.execute(sql, val)
    result = my_cursor.fetchall()
    if result:
        return (1)
    else:
        return (0)


def swap_monim(my_cursor,old_mone,new_mone):
    print ("swap ")
def swap_fathers(my_cursor, old_mone, new_mone):
    print("swap ")
def change_mone_av(my_cursor,old_mone,new_mone):
    print ("change mone_av")
def update_status_mone(my_cursor, mone,status):
    print ("update_status_mone(my_cursor, _mone ")
    sql = "update monim set status=%s where mone =%s"
    val=(status,mone)
    my_cursor.execute(sql,val)

def update_status(my_cursor,ch_record_number,status,tozaa):
    sql="update change_monim set status=%s,result=%s where record_number=%s"
    val=(status,tozaa,ch_record_number)
    my_cursor.execute(sql, val)


def change_monim (my_cursor):
    print ("entered  cahange monim")
    sql ="select  neches,old_mone,old_reading,new_mone,new_reading,new_neches,degem ,degem_name,op ,record_number from change_monim where status<1"
    my_cursor.execute(sql)
    result=my_cursor.fetchall()
    print (result)
    for y in list(result):
        neches=y[0]
        old_mone=y[1]
        old_reading=y[2]
        new_mone=y[3]
        new_reading=y[4]
        new_neches=y[5]
        degem=y[6]
        degem_name=y[7]
        op=y[8]
        ch_record_number=y[9]

        # op  1 switch old_new
        # op  2 remove old
        # op  3 install new
        if is_neches(my_cursor, neches) == 0:
            print("error - no neches")
        else:
            if op == 0:
                print("op =0 nothing done")
            elif op==1 :
                print ("switch between old and new")
                if is_mone_neches(my_cursor,old_mone,neches)==0:
                    print ("error - no such old__mone or neches")
                elif is_mone_neches(my_cursor, new_mone, new_neches) == 0:
                        print("error - no such_new mone or neches")
                sql="update monim set neches =%s where mone=%s"
                val=(new_neches,old_mone)
                my_cursor.execute(sql, val)
                val = (neches, new_mone)
                my_cursor.execute(sql, val)

                #swap_fathers(my_cursor, old_mone, new_mone)
                #change_mone_av(my_cursor,old_mone,new_mone)
                #add_transactions(my_cursor,old_mone,old_qty,new_mone,new_qty) # should be done
            elif op==2:
                print ("remove old mone")
                if is_mone_neches(my_cursor, new_mone, new_neches) == 0:
                    print("error - no such_mone or neches to disable")
                else:
                    update_status_mone(my_cursor,old_mone,"mone_porak")
                    update_status(my_cursor, ch_record_number, 1, "mone porak")

            elif op == 3:
                print("install new mone")
                print("Easy = just change mispar mone")
                if is_neches (my_cursor,new_neches)==1:
                        #if is_mone_neches(my_cursor,new_mone,"1234")==0 :#ein  mone_panui
                        #print ("error -  mone lo panui or no such mone (1234) ")
                        sql= "update monim set neches=%s where mone=%s "
                        val=(neches,new_mone )
                        my_cursor.execute(sql,val)
                        print ("new_mone inserted check father ")
                        update_status(my_cursor,ch_record_number,1,"ok")
                else:
                    print ("no_neches")
                    update_status(my_cursor, ch_record_number, 0, "no neches")
                #-------------      no father for old mone --------------

def check_update_neches_monim(my_cursor):#  just see all monim with no father will get father
    sql="select neches,record_number  from monim "
    my_cursor.execute (sql)
    results=my_cursor.fetchall()
    for y in list(results):
        neches =y[0]
        record_number=y[1]
        sql="select neches from customers where neches = %s"
        val=(neches)
        my_cursor.execute(sql,val)
        results1 = my_cursor.fetchall()
        if list(results1):
            print ("Ok)")
        else:
            print (neches)
            sql="update monim set neches ='1234' where record_number =%s"
            val=(record_number)
            #my_cursor.execute(sql,val)

####@check_update_neches_monim(mycursor)
change_monim(mycursor)



# ##########################################################################






new_ratsif2yomi(mycursor,'2020-01-01')
calculate_qty_in_ratsif(mycursor)
update_last_transmission(mycursor)
calculate_virtual_monim(mycursor)




