from http.server import HTTPServer, SimpleHTTPRequestHandler, ThreadingHTTPServer

from io import BytesIO
from urllib.parse import urlparse
from urllib.parse import unquote
from urllib.parse import quote
# import pyodbc
import json
from datetime import datetime
import time
import os
import aniso8601
import json
import requests
import uuid
import urllib.request
import urllib.parse
import pymysql

from datetime import datetime
#import standard_utils

# database ="movedb"
print("program started\n")
# print("read config file: db= ", {database})
# print(database)
# print(f'Driver={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={database};')
omone = ""
oreading_date = ""

config = json.load(open(os.path.join(os.path.dirname(__file__), "config_my.json")))

print(config)

database = config["database"]
SERVER_IP = config["SERVER_IP"]
user = config["user"]
password = config["password"]


def my_open(datab):
    print ("datab=",datab, "localhost")
    if datab == "":
        db = pymysql.connect(
            host="localhost",
            user=user,
            passwd=password,
        )
        print("connected to mysql")
        mycursor = db.cursor()
        return (mycursor, db)

    else:
        db = pymysql.connect(
            host="localhost",
            user=user,
            passwd=password,
            database=datab,
            autocommit=1,
        )
        print("db opened", db)
        mycursor = db.cursor()
        return (mycursor, db)





def aalt_open(datab):
    if datab == "":
        db =  pymysql.connect(
            host="31.220.61.40",
            user="jony",
            passwd=8341455,
        )
        print("connected to mysql")
        mycursor = db.cursor()
        return (mycursor, db)

    else:
        db =  pymysql.connect(
            host="31.220.61.40",
            user="jony",
            passwd="8341455",
            database= datab ,
            autocommit=1,

        )
        print("db opened", db)
        mycursor = db.cursor()
        return (mycursor, db)


# mycursor, my_db = my_open(database)


############my_altcursor,my_db =alt_open("move_ver3")

mycursor, my_db = my_open(database)
#mycursor, my_db = aalt_open(database)


from datetime import date

now = datetime.now()
s1 = now.strftime("%d/%m/%Y")
s2 = now.strftime("%d/%m/%Y %H:%M")
print("s2 =", s2)

# standard_utils.get_all_values(mycursor)

def add_log(my_cursor,day_date,description,qty,status):
    sql= "insert into log (day_date,description,qty,status) values (%s,%s,%s,%s)"
    val= (day_date,description,qty,status)
    my_cursor.execute (sql,val)

def alarms(my_cursor, day_date, mone, alarm_no, qty, details, priority, status):
    print(" a l a r m s",mone,alarm_no)
    now = datetime.now()

    dt_string = now.strftime("%Y/%m/%d %H:%M:%S")
    sql = "select day_date from alarms where day_date= %s and mone= %s and alarm_index= %s"
    val = (day_date, mone, alarm_no)
    my_cursor.execute(sql, val)
    result = my_cursor.fetchall()
    y_list = list(result)
    if y_list:
        print("alarm exists",alarm_no)
    else:
        print("*** new  alarm ***")
        sql = "INSERT into alarms  ( day_date,mone,alarm_index,alarm_description,qty,inserted_at,priority,status) values   (%s,%s,%s,%s,%s,%s ,%s,%s)"
        val = (day_date, mone, alarm_no, details, qty, dt_string, priority, status)
        print(sql)
        print(val)
        my_cursor.execute(sql, val)
        # conn.commit()
        return ("OK")

    def new_find_in_yomi(my_cursor, day_date, mone):
        # check if this record exists

        sql = "select mone from kriot_yomi where day_date= %s and mone = %s  "
        val = (day_date, mone)
        my_cursor.execute(sql, val)
        res = my_cursor.fetchall()
        tmp = list(res)
        print(tmp)
        if tmp:
            f = 0  # exists
            print("=== exists ***")
        else:
            f = 1
            print("does not exist")
        return (f)

def new_find_in_yomi(my_cursor, day_date, mone):
    # check if this record exists
    sql = "select mone from kriot_yomi where day_date= %s and mone = %s  "
    val = (day_date, mone)
    my_cursor.execute(sql, val)
    res = my_cursor.fetchall()
    tmp = list(res)
    print(tmp)
    if tmp:
        f = 0  # exists
        print("=== exists ***")
    else:
        f = 1
        print("does not exist")
    return (f)

def find_sons(my_cursor,mone):
    sql= "select count(mone) from monim where mone_av=%s "
    val=(mone)
    my_cursor.execute(sql,val)
    result=my_cursor.fetchall()

    y_list=list(result)
    num=0
    if y_list:
        for y in y_list :
            num=y[0]
    print ("num=",num)
    return (num)

def update_sons(my_cursor):
    print ("updating total sons in monim")
    # first i want all fathers
    sql = "select mone_av from view_yomi  group by mone_av"  # order by diameter"
    my_cursor.execute(sql)
    result = my_cursor.fetchall()
    count_insert = 0
    count_update = 0
    for y in list(result):
        mone_av = y[0]
        total_sons = find_sons(my_cursor, mone_av)
        sql="update monim set total_sons = %s where mone =%s"
        val=(total_sons, mone_av)
        if total_sons>0:
             print ("val= ",val)
             try:
                my_cursor.execute(sql,val)
             except:
                 print ("no_such father ",val)

def new_update_phat(my_cursor, from_date):
    # first i want all fathers
    sql = "select mone_av from view_yomi  group by mone_av"  # order by diameter"
    my_cursor.execute(sql)
    result = my_cursor.fetchall()
    count_insert=0
    count_update=0
    for y in list(result):
        mone_av = y[0]
        total_sons = find_sons(my_cursor,mone_av)

        print("++++++++++++++++++++++++++++++++ mone-av", mone_av,total_sons)
        # now i want all dates where there are qty
        sql = "select day_date from view_yomi where  mone_av =  %s and day_date >=  %s  and qty <> 0   group by day_date"
        val = (mone_av, from_date)
        my_cursor.execute(sql, val)
        result1 = my_cursor.fetchall()
        for day_date in list(result1):
            # now i find sum of qty
            sql = "select sum(qty) ,count(qty)  from view_yomi where mone_av=%s and day_date=%s"
            val = (mone_av, day_date)
            # print (val)
            my_cursor.execute(sql, val)
            result2 = my_cursor.fetchall()
            print ("+++++++++++++++++++++++++++++++++++++++++---")
            tmp = list(result2)
            for ii in tmp:
                real_qty = ii[0]
                current_sons = ii[1]
            print(mone_av, day_date, tmp,current_sons)
            # now insert update reakqty for phat
            f = new_find_in_yomi(my_cursor, day_date, mone_av)
            dif_sons= total_sons-current_sons
            if f == 0:
                sql = "update kriot_yomi set real_qty =%s ,dif_sons =%s where day_date=%s and mone=%s"
                val = (real_qty,dif_sons, day_date, mone_av)
                count_update=count_update+1
            else:
                sql = " insert into kriot_yomi (day_date,mone,real_qty,dif_sons) values (%s,%s,%s,%s)"
                val = (day_date, mone_av, real_qty,dif_sons)
                count_insert=count_insert+1

            if real_qty != 0:
                my_cursor.execute(sql, val)
    now = datetime.now()
    s1 = now.strftime("%d/%m/%Y")
    s2 = now.strftime("%d/%m/%Y %H:%M")
    add_log(my_cursor, now, "phat _new_ insert ",count_insert,"0")
    add_log(my_cursor, now, "phat _update ", count_update, "0")



def calculate_virtual_monim(my_cursor): # kevel 1
    print ("entered calculate virtual")
    # found all virtuals
    sql ="select virtual_mone,real_mone from virtual_monim order by calculation_order"
    my_cursor.execute(sql)
    result=my_cursor.fetchall()
    y_list=list(result)
    if (y_list):
        for y in y_list:
             v_mone=y[0]
             real_mone=y[1]
             print (v_mone,real_mone)
             #found all dates in for each real mone
             sql =" select day_date,former_reading,last_reading,balance,real_qty from kriot_yomi where mone=%s"
             val = real_mone
             my_cursor.execute(sql,val)
             result1=mycursor.fetchall()
             z_list=list (result1)

             for  z in z_list:
                 print (z)
                 day_date= z[0]
                 former_reading =z[1]
                 last_reading=z[2]
                 balance =z[3]
                 real_qty=z[4]
                 # check if exists
                 sql = "select record_number from kriot_yomi where day_date=%s and mone=%s"
                 val=(day_date,v_mone)
                 #find if
                 my_cursor.execute (sql,val)
                 temp_result = my_cursor.fetchall()
                 temp =list (temp_result)
                 if temp :# update record
                     for r in temp:
                        sql = "update kriot_yomi set former_reading =%s,last_reading=%s,balance=%s,real_qty=%s where record_number=%s"
                        val=(former_reading,last_reading,balance,real_qty,r[0])
                        my_cursor.execute(sql, val)
                        print ("updating")
                 else:
                     sql = "insert into kriot_yomi (mone, day_date,former_reading,last_reading,balance,real_qty ) values ( %s,%s,%s,%s,%s,%s )"
                     val = (v_mone,day_date,former_reading, last_reading, balance, real_qty )
                     print ("inserting new")
                     my_cursor.execute(sql, val)



update_sons(mycursor)

new_update_phat(mycursor, '2020-00-00')
calculate_virtual_monim(mycursor)
