import pymysql
print ("$$$$$$$$$$$$$$$$$$$$$$$$$$$")
print ("$                         $")
print ("## loaded module db_open ##")
print ("$                         $")
print ("$$$$$$$$$$$$$$$$$$$$$$$$$$$")
def my_open(my_database,my_address,my_user,my_password):
    if my_database != "":
        print ("database=",my_database,my_address,my_user,my_password)
        db = pymysql.connect(host=my_address, user=my_user, passwd=my_password, database=my_database,autocommit=1, )
        print ("*** mysql opend  db ok ***")
        mycursor = db.cursor()
    else:
        db = pymysql.connect(host=my_address, user=my_user, passwd=my_password, autocommit=1, )
        print("db opened", db)
        mycursor = db.cursor()
        print("mysql opend with no db")
    return (mycursor, db)

#mycursor,db=my_open("move_ver3","localHost", "root","1234")

def create_database(my_cursor,db_name):
    sql= "CREATE DATABASE IF NOT EXISTS "+db_name + " /*!40100 DEFAULT CHARACTER SET utf8mb4 */;"
    try:
        print (sql)
        my_cursor.execute(sql)
        print ("database ",db_name ," created succseefully")
        err=0
    except:
        print ("* * * * * *ERROR creating database ",db_name)
        err=1
        return (err)


def drop_database(my_cursor, db_name):
    sql ="drop database "+ db_name
    try:
        my_cursor.execute(sql)
        print ("database ", db_name ," DELETED succseefully")
        err=0
    except:
        print ("*** **  ERROR Deleating dataabase ", db_name)
        err=1
        return (err)


import sys
import cv2
import urllib.request
import urllib.parse
from urllib.parse import quote
from datetime import datetime
from datetime import timedelta
from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import QApplication, QWidget, QLabel,QCheckBox
from PyQt5.QtGui import  QPixmap
import json
#import my_lior_lib
#impot my_utils
import os
import shutil


import time
import serial

def show_fields(a_class):
    # COPY TO CLASS AND REMOVE CALL
    print("#                =======")
    print("#                buttons")
    print("#                =======")
    all_buttons = a_class.findChildren(QtWidgets.QPushButton)
    for but in all_buttons:
        # print(but.objectName())
        print("self." + but.objectName() + " = self.findChild(QtWidgets.QPushButton,'" + but.objectName() + "')")
    print("#                 =======")
    print("#                   lines")
    print("#                 =======")
    all_line = a_class.findChildren(QtWidgets.QLineEdit)
    for line in all_line:
        print("self." + line.objectName() + " = self.findChild(QtWidgets.QLineEdit,'" + line.objectName() + "')")

    print("#                 =======")
    print("#                  labels")
    print("#                 =======")
    all_label = a_class.findChildren(QtWidgets.QLabel)
    for label in all_label:
        print("self." + label.objectName() + " = self.findChild(QtWidgets.QLabel,'" + label.objectName() + "')")
    print("#                 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%")
    print("#                  p r o c e d u r e s    d e c l e r a t i o n s")
    print("#                 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%")

    all_buttons = a_class.findChildren(QtWidgets.QPushButton)
    for but in all_buttons:
        # print(but.objectName())
        print("self." + but.objectName() + ".clicked.connect(self." + but.objectName() + "_PRESSED)")

    print("#                 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%")
    print("#                  p r o c e d u r e s    s k e l e t o n ")
    print("#                 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%")

    all_buttons = a_class.findChildren(QtWidgets.QPushButton)
    s = "\""
    print("# @@ - ")
    for but in all_buttons:
        print("# - ")
        print("def " + but.objectName() + "_PRESSED (self) :")
        print("   print(" + s + "entered " + but.objectName() + "_PRESSED" + s + ")")
    print("#+++")

def find_and_fill(data_str,index_array,sep ):
#get vector split -put values in the corresponding array of indext names

    if sep =="":
        sep="&"
    out_str= []
    for i in range (100):
        out_str.append(" ")
    out_str[99]="99"
    tmp_array=data_str.split(sep)
    i=0
    for x in tmp_array:
        p= (x.find ("="))
        p1=x[0:p]
        p2=x[p+1:]
        #print (p1)
        #print (p2)
        for j in range (0,len (index_array)):
            if (p1.lstrip()==index_array[j]):
               out_str[j]=p2
        i=i+1
    for j in range (0,len(index_array)):
        print (j,index_array[j],"=",out_str[j])
    return (out_str)

    # the oposit - prepare for http

def load_configuration(db):
    config = json.load(open(os.path.join(os.path.dirname(__file__), "config_my.json")))

    print(config)
    print ("----- new standard for debug-------")
    import db_open
    database = config["database"]
    server_ip = config["server_ip"]
    user = config["user"]
    password = config["password"]

    alt_database = config["alt_database"]
    alt_server_ip = config["alt_server_ip"]
    alt_user = config["alt_user"]
    alt_password = config["alt_password"]
    mycursor, my_db = db_open.my_open(database, server_ip, user, password)
    my_alt_cursor, my_alt_db = db_open.my_open(alt_database, alt_server_ip, alt_user, alt_password)
    return mycursor,my_alt_cursor




def add_empty_columns( ):
    #my_cursor,db = my_open("load_excel_parameters", "localhost",  "root", "1234")
    my_cursor, db = my_open("move_ver3", "localHost", "root", "1234")
    fname ="load_excel_import"
    for i in range (0,50):
        s1="col_"+str(i)
        s2="field_"+str(i)
        s3="target_field_"+str(i)
        s4="convesion_"+str(i)
        sql= "alter table "+fname+ " ADD "+s1+" varchar(50)"
        my_cursor.execute(sql)
        sql = "alter table "+fname+ " ADD " + s2 + " varchar(50)"
        my_cursor.execute(sql)
        sql = "alter table "+fname+ " ADD " + s3 + " varchar(50)"
        print (sql)
        my_cursor.execute(sql)
        sql = "alter table " + fname + " ADD " + s4 + " varchar(50)"
        print(sql)
        my_cursor.execute(sql)



#add_empty_columns( )

#ycursor, my_db = db_open.my_open(database,server_ip,user,password)

#my_alt_cursor, my_alt_db=db_open.my_open(alt_database,alt_server_ip,alt_user,alt_password)


#my_alt_cursor, my_alt_db=db_open.my_open(alt_database,alt_server_ip,alt_user,alt_password)



